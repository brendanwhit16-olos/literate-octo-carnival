# Research agenda — known gaps and next investigations

Gap 1: Administrative & Institutional Intentions (Player / History)
What to find out: Do local election officials and county clerks view current procedural friction as a necessary protective security buffer or as an administrative liability?

Method: Semi-structured qualitative interviews (30–45 mins).

Tool: Go talk to people + Claude (for cross-interview theme synthesis).

What it would change: Proves whether administrative complexity is maintained deliberately as a gatekeeping moat or passively due to budget/staffing starvation.

Gap 2: The Intentional Non-Voter / Exited Citizen (Player / Value)
What to find out: Is disengagement among non-voters caused by a lack of scaffolding/information, or is it a calculated refusal to participate in an extractive system?

Method: Focus groups and qualitative survey sampling.

Tool: Perplexity (for secondary demographic literature on non-voter motivations) + NotebookLM (deep synthesis of transcript data).

What it would change: Tests whether building a "Civic Playbook" would actually re-engage exited citizens or if it falsely assumes everyone wants to participate.

Gap 3: Working Counter-Examples / Functional Scaffolding (Counterfactual)
What to find out: Are there municipal jurisdictions (US or international) where binding public participation models (e.g., participatory budgeting) successfully prevented "false transparency" burnout?

Method: Deep research sweep of academic literature and civic tech case studies.

Tool: Perplexity (grounded web/literature research) + NotebookLM (analyzing case study documents).

What it would change: Validates whether the "Voice Simulation Paradox" is an inevitable feature of public governance or a solvable structural design flaw.